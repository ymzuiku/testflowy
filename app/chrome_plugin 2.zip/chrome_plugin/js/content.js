// const oldFetch = fetch;
// fetch = (url, ...rest) => {
//   if (/testflowy\.com/.test(url)) {
//     console.log("--debug--proxy", url);
//     return new Promise((result) => {
//       chrome.runtime.sendMessage(
//         {
//           info: {
//             url,
//             ...rest,
//           },
//         },
//         (value) => {
//           return result({
//             text: async () => value,
//           });
//         },
//       );
//     });
//   }
//   return oldFetch(url, ...rest);
// };
// //  "Content-Type": "application/json;charset=utf-8",
// fetch("https://testflowy.com/sdk.js", {
//   headers: {
//     "Content-Type": "text",
//   },
//   method: "GET",
// })
//   .then((v) => v.text())
//   .then((v) => {
//     console.log("--debug--v2", v);
//   });

(function (d) {
  var s = d.createElement("script");
  s.src = "https://testflowy.com/sdk.js";
  s.async = true;
  (d.head || d.body).appendChild(s);
})(document);
