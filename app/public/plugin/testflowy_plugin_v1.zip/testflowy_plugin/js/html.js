const div = document.createElement("div");
div.textContent = "hotkey: F5(or shift+F5) Enable the Testflowy tools";
document.body.append(div);
